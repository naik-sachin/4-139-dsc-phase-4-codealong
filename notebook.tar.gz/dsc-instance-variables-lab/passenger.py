# define passenger class here
