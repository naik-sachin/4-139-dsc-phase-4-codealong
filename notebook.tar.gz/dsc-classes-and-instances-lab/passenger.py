class Passenger:
    pass
