class Ride:
    pass
